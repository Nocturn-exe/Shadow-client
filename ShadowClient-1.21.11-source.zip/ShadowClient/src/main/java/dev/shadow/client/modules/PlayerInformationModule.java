package dev.shadow.client.modules;

import dev.shadow.client.module.*;
import net.minecraft.client.Minecraft;

public final class PlayerInformationModule extends ClientModule {
    private String coordinates = "N/A";
    private float health;
    private int armor;
    public PlayerInformationModule() {
        super("Player Information", "Displays basic player and session telemetry.", Category.PLAYER);
        defineFlag("coordinates", true); defineFlag("healthArmor", true);
    }
    @Override public void tick(Minecraft mc) {
        if (mc.player == null) { coordinates = "N/A"; health = 0; armor = 0; return; }
        coordinates = flag("coordinates") ? String.format("%.1f, %.1f, %.1f",
                mc.player.getX(), mc.player.getY(), mc.player.getZ()) : "Hidden";
        health = mc.player.getHealth();
        armor = mc.player.getArmorValue();
    }
    public String coordinates() { return coordinates; }
    public float health() { return health; }
    public int armor() { return armor; }
}
