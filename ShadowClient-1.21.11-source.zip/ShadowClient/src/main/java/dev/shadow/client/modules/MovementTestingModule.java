package dev.shadow.client.modules;

import dev.shadow.client.module.*;
import net.minecraft.client.Minecraft;

public final class MovementTestingModule extends ClientModule {
    private double horizontalSpeed;
    private double verticalSpeed;
    private double previousX, previousY, previousZ;
    private boolean initialized;
    public MovementTestingModule() {
        super("Movement Testing", "Measures player movement without changing physics.", Category.MOVEMENT);
        defineFlag("measureVertical", true);
    }
    @Override public void tick(Minecraft mc) {
        if (mc.player == null) { initialized = false; return; }
        double x = mc.player.getX(), y = mc.player.getY(), z = mc.player.getZ();
        if (initialized) {
            horizontalSpeed = Math.hypot(x - previousX, z - previousZ) * 20.0;
            verticalSpeed = flag("measureVertical") ? (y - previousY) * 20.0 : 0;
        }
        previousX = x; previousY = y; previousZ = z; initialized = true;
    }
    public double horizontalSpeed() { return horizontalSpeed; }
    public double verticalSpeed() { return verticalSpeed; }
}
