package dev.shadow.client.modules;

import dev.shadow.client.module.*;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;

public final class EntityAnalysisModule extends ClientModule {
    private int nearbyEntities;
    private double nearestDistance = -1;
    public EntityAnalysisModule() {
        super("Entity Analysis", "Observes nearby entities and target distance.", Category.ENTITY);
        defineFlag("includePlayers", true); defineFlag("includeMobs", true);
    }
    @Override public void tick(Minecraft mc) {
        if (mc.level == null || mc.player == null) { nearbyEntities = 0; nearestDistance = -1; return; }
        int count = 0; double nearest = Double.MAX_VALUE;
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (entity == mc.player || !entity.isAlive()) continue;
            boolean player = entity instanceof net.minecraft.world.entity.player.Player;
            if ((player && !flag("includePlayers")) || (!player && !flag("includeMobs"))) continue;
            count++;
            nearest = Math.min(nearest, mc.player.distanceTo(entity));
        }
        nearbyEntities = count; nearestDistance = count == 0 ? -1 : nearest;
    }
    public int nearbyEntities() { return nearbyEntities; }
    public double nearestDistance() { return nearestDistance; }
}
