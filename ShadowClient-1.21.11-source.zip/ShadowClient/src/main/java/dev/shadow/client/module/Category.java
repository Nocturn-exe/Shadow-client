package dev.shadow.client.module;
public enum Category { ENTITY, INTERACTION, MOVEMENT, WORLD, PLAYER }
