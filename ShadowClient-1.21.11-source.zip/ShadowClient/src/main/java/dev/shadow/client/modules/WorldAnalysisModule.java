package dev.shadow.client.modules;

import dev.shadow.client.module.*;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

public final class WorldAnalysisModule extends ClientModule {
    private String dimension = "N/A";
    private int chunkX, chunkZ;
    private String blockName = "N/A";
    public WorldAnalysisModule() {
        super("World Analysis", "Reports dimension, chunk and looked-at block data.", Category.WORLD);
        defineFlag("showChunk", true); defineFlag("showBlock", true);
    }
    @Override public void tick(Minecraft mc) {
        if (mc.level == null || mc.player == null) { dimension = "N/A"; blockName = "N/A"; return; }
        dimension = mc.level.dimension().location().toString();
        chunkX = mc.player.chunkPosition().x; chunkZ = mc.player.chunkPosition().z;
        if (flag("showBlock") && mc.hitResult instanceof net.minecraft.world.phys.BlockHitResult hit) {
            BlockPos pos = hit.getBlockPos();
            blockName = mc.level.getBlockState(pos).getBlock().toString();
        } else blockName = "N/A";
    }
    public String dimension() { return dimension; }
    public int chunkX() { return chunkX; }
    public int chunkZ() { return chunkZ; }
    public String blockName() { return blockName; }
}
