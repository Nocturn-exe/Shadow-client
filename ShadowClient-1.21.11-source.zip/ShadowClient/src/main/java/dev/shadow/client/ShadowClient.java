package dev.shadow.client;

import dev.shadow.client.config.ConfigManager;
import dev.shadow.client.gui.ShadowClickScreen;
import dev.shadow.client.module.ModuleManager;
import dev.shadow.client.modules.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

public final class ShadowClient implements ClientModInitializer {
    public static final String MOD_ID = "shadowclient";
    public static final ModuleManager MODULES = new ModuleManager();
    public static final ConfigManager CONFIG = new ConfigManager();
    private static KeyMapping openGui;

    @Override public void onInitializeClient() {
        MODULES.register(new EntityAnalysisModule());
        MODULES.register(new InteractionTelemetryModule());
        MODULES.register(new MovementTestingModule());
        MODULES.register(new WorldAnalysisModule());
        MODULES.register(new PlayerInformationModule());

        CONFIG.load(MODULES);
        openGui = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.shadowclient.open_gui", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, "category.shadowclient"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGui.consumeClick()) client.setScreen(new ShadowClickScreen());
            MODULES.tick(client);
        });
    }
}
