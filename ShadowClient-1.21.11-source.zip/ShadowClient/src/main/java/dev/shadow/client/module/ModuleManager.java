package dev.shadow.client.module;

import net.minecraft.client.Minecraft;
import java.util.*;

public final class ModuleManager {
    private final Map<String, ClientModule> modules = new LinkedHashMap<>();
    public void register(ClientModule module) {
        if (modules.putIfAbsent(module.name().toLowerCase(Locale.ROOT), module) != null)
            throw new IllegalArgumentException("Duplicate module: " + module.name());
    }
    public Collection<ClientModule> all() { return Collections.unmodifiableCollection(modules.values()); }
    public Optional<ClientModule> find(String name) { return Optional.ofNullable(modules.get(name.toLowerCase(Locale.ROOT))); }
    public void tick(Minecraft client) {
        for (ClientModule module : modules.values()) if (module.enabled()) module.tick(client);
    }
}
