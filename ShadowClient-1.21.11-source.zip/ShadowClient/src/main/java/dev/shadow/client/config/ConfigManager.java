package dev.shadow.client.config;

import com.google.gson.*;
import dev.shadow.client.module.*;
import net.fabricmc.loader.api.FabricLoader;
import java.io.*;
import java.nio.file.*;

public final class ConfigManager {
    private final Path file = FabricLoader.getInstance().getConfigDir().resolve("shadow-client.json");
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public void load(ModuleManager manager) {
        if (!Files.exists(file)) return;
        try (Reader reader = Files.newBufferedReader(file)) {
            JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
            for (ClientModule module : manager.all()) {
                JsonObject item = root.has(module.name()) ? root.getAsJsonObject(module.name()) : null;
                if (item == null) continue;
                if (item.has("enabled")) module.setEnabled(item.get("enabled").getAsBoolean());
                if (item.has("settings")) {
                    JsonObject settings = item.getAsJsonObject("settings");
                    for (String key : settings.keySet()) module.setFlag(key, settings.get(key).getAsBoolean());
                }
            }
        } catch (Exception ex) { System.err.println("[Shadow Client] Config load failed: " + ex.getMessage()); }
    }
    public void save(ModuleManager manager) {
        JsonObject root = new JsonObject();
        for (ClientModule module : manager.all()) {
            JsonObject item = new JsonObject();
            item.addProperty("enabled", module.enabled());
            JsonObject settings = new JsonObject();
            module.flags().forEach(settings::addProperty);
            item.add("settings", settings);
            root.add(module.name(), item);
        }
        try {
            Files.createDirectories(file.getParent());
            try (Writer writer = Files.newBufferedWriter(file)) { gson.toJson(root, writer); }
        } catch (IOException ex) { System.err.println("[Shadow Client] Config save failed: " + ex.getMessage()); }
    }
}
