package dev.shadow.client.gui;

import dev.shadow.client.ShadowClient;
import dev.shadow.client.module.ClientModule;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.ArrayList;
import java.util.List;

public final class ShadowClickScreen extends Screen {
    private final List<ClientModule> visible = new ArrayList<>();
    private String search = "";
    private int scroll;
    public ShadowClickScreen() { super(Component.literal("Shadow Client")); refresh(); }
    private void refresh() {
        visible.clear();
        for (ClientModule module : ShadowClient.MODULES.all())
            if (module.name().toLowerCase().contains(search.toLowerCase())
                    || module.category().name().toLowerCase().contains(search.toLowerCase())) visible.add(module);
    }
    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        renderBackground(g, mouseX, mouseY, delta);
        int left = width / 2 - 150, top = height / 2 - 115;
        g.fill(left, top, left + 300, top + 230, 0xF0181B24);
        g.fill(left, top, left + 300, top + 27, 0xFF252B3A);
        g.drawString(font, "SHADOW CLIENT", left + 12, top + 9, 0xFFB9A0FF);
        g.drawString(font, "Click a module to toggle  |  / search  |  ESC close", left + 12, top + 34, 0xFFB8BFCE);
        int y = top + 53;
        for (int i = scroll; i < Math.min(visible.size(), scroll + 8); i++) {
            ClientModule m = visible.get(i);
            boolean hover = mouseX >= left + 10 && mouseX <= left + 290 && mouseY >= y - 3 && mouseY <= y + 12;
            g.fill(left + 9, y - 4, left + 291, y + 15, hover ? 0xFF343B4D : 0xFF222835);
            g.drawString(font, m.name() + "  [" + m.category() + "]", left + 16, y, 0xFFE4E7EF);
            g.drawString(font, m.enabled() ? "ON" : "OFF", left + 258, y, m.enabled() ? 0xFF75E0A0 : 0xFF8991A2);
            y += 22;
        }
        g.drawString(font, "Search: " + (search.isEmpty() ? "(none)" : search), left + 12, top + 213, 0xFF9EA7B8);
        super.render(g, mouseX, mouseY, delta);
    }
    @Override public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int left = width / 2 - 150, top = height / 2 - 115;
            int row = (int) ((mouseY - (top + 49)) / 22) + scroll;
            if (mouseX >= left + 9 && mouseX <= left + 291 && row >= 0 && row < visible.size()) {
                visible.get(row).toggle(); ShadowClient.CONFIG.save(ShadowClient.MODULES); return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }
    @Override public boolean charTyped(char c, int modifiers) {
        if (!Character.isISOControl(c)) { search += c; refresh(); scroll = 0; return true; }
        return super.charTyped(c, modifiers);
    }
    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 259 && !search.isEmpty()) { search = search.substring(0, search.length() - 1); refresh(); return true; }
        if (keyCode == 265) { scroll = Math.max(0, scroll - 1); return true; }
        if (keyCode == 264) { scroll = Math.min(Math.max(0, visible.size() - 8), scroll + 1); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
    @Override public void onClose() { ShadowClient.CONFIG.save(ShadowClient.MODULES); super.onClose(); }
    @Override public boolean isPauseScreen() { return false; }
}
