package dev.shadow.client.modules;

import dev.shadow.client.module.*;
import net.minecraft.client.Minecraft;

/** Passive telemetry only: deliberately does not synthesize clicks or send interaction packets. */
public final class InteractionTelemetryModule extends ClientModule {
    private long ticksObserved;
    private long lastAttackNanos;
    private double lastAttackIntervalMs = -1;
    public InteractionTelemetryModule() {
        super("Interaction Telemetry", "Measures observed attack-input timing; no input automation.", Category.INTERACTION);
        defineFlag("measureIntervals", true);
    }
    @Override public void tick(Minecraft mc) {
        if (mc.player == null) return;
        ticksObserved++;
        // Input is sampled only as telemetry; no action is triggered.
        if (flag("measureIntervals") && mc.options.keyAttack.isDown()) {
            long now = System.nanoTime();
            if (lastAttackNanos != 0) lastAttackIntervalMs = (now - lastAttackNanos) / 1_000_000.0;
            lastAttackNanos = now;
        }
    }
    public long ticksObserved() { return ticksObserved; }
    public double lastAttackIntervalMs() { return lastAttackIntervalMs; }
}
