package dev.shadow.client.module;

import net.minecraft.client.Minecraft;
import java.util.LinkedHashMap;
import java.util.Map;

public abstract class ClientModule {
    private final String name;
    private final String description;
    private final Category category;
    private boolean enabled;
    private final Map<String, Boolean> flags = new LinkedHashMap<>();

    protected ClientModule(String name, String description, Category category) {
        this.name = name; this.description = description; this.category = category;
    }
    public final String name() { return name; }
    public final String description() { return description; }
    public final Category category() { return category; }
    public final boolean enabled() { return enabled; }
    public final void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        if (value) onEnable(); else onDisable();
    }
    public final void toggle() { setEnabled(!enabled); }
    protected void onEnable() {}
    protected void onDisable() {}
    public void tick(Minecraft client) {}
    protected final void defineFlag(String id, boolean initial) { flags.put(id, initial); }
    public final Map<String, Boolean> flags() { return flags; }
    public final boolean flag(String id) { return flags.getOrDefault(id, false); }
    public final void setFlag(String id, boolean value) {
        if (flags.containsKey(id)) flags.put(id, value);
    }
}
