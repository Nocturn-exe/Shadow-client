# Shadow Client (experimental framework)

Client-only Fabric project targeting Minecraft Java 1.21.11.

## Build
- Install JDK 21 and a recent Gradle distribution.
- Run `gradle build` (or generate a wrapper with `gradle wrapper` first).
- The remapped mod jar is produced in `build/libs/`.
- Install Fabric Loader for 1.21.11 and Fabric API, then place the jar in `.minecraft/mods`.

## Controls
- Right Shift opens the module screen.
- Click a row to toggle a module.
- Type to filter modules; Backspace edits the filter; Up/Down scroll.
- Configuration is saved to `config/shadow-client.json`.

## Included modules
- Entity Analysis: nearby entity count and nearest distance; player/mob filters.
- Interaction Telemetry: passive sampling of held attack input and interval estimate.
- Movement Testing: horizontal and vertical movement speed estimates.
- World Analysis: dimension, chunk coordinates and targeted block identifier.
- Player Information: coordinates, health and armor.

## Scope and limitations
This is a conservative, observational foundation, not a finished competitive client. It does not synthesize mouse input, automate sprinting, change reach, alter movement/flight physics, modify packets, or provide server-side advantages. Interaction telemetry samples the held attack key and is therefore an approximate held-state interval, not a true click counter.

The initial GUI is a functional searchable module toggle screen. A full drag-and-drop HUD editor, animated category sidebar, render-world overlays, per-module numeric/color controls, and automated interaction tests are follow-on work. They need dedicated render hooks and version-specific validation.

## Minecraft 1.21.11 compatibility notes
Fabric's 1.21.11 guidance recommends Loom 1.14 and official Mojang mappings; Yarn is no longer the recommended mapping path for this version. This project uses official mappings and Java 21. Dependency versions are declared in `gradle.properties`; check Fabric's version metadata if newer compatible builds are available.

## Validation
The source was assembled against the documented 1.21.11 toolchain conventions. This environment does not have a configured Minecraft/Gradle build runtime, so a successful `gradle build` or in-game test is **not claimed**. Run the build locally and resolve any API drift reported by the compiler before distributing.
